package com.gcdesigns.assignment.service;

import com.gcdesigns.assignment.dto.AggregatedResult;

import java.util.List;

/**
 * @author Shashank Kumar Shukla
 * @created_at : 10/09/2023 - 10:51 pm
 * @mail_to: shashank.shukla@rapipay.com
 */
public interface IMongoService {
    List<AggregatedResult> getAggregation();
}
